import csv
with open("file.csv","r") as csvfile:
    data=Data_Terminals.reader(csvfile)
    for row in data:
        print(row)