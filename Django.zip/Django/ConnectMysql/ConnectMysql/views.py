
from rest_framework.response import Response
from rest_framework.decorators import api_view



@api_view(['GET'])
def showemp(request):
    if request.method=='GET':
    results=Empmodel.objects.all()
    serialize=Serializationclass(results,many=True)
    return Response(data_terminals)

def displaydata(request):
    callapi=requests.get('http://127.0.0.1:8000/Show')  
    results=callapi.json()
    return render(request    